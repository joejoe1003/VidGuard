const hre = require("hardhat");

async function main() {
  const [deployer] = await hre.ethers.getSigners();
 // const contractAddress = 
  const MyNFT = await hre.ethers.getContractFactory("MyNFT");
  const myNFT = MyNFT.attach(contractAddress);

  const tx = await myNFT.mint(deployer.address);
  await tx.wait();
  console.log("NFT minted to:", deployer.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});