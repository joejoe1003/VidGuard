require('dotenv').config();
const { ethers } = require('ethers');

//const INFURA_API_KEY = 
const provider = new ethers.JsonRpcProvider(`https://sepolia.infura.io/v3/${INFURA_API_KEY}`);
const wallet = new ethers.Wallet(process.env.PRIVATE_KEY, provider);



const hashToStore = 'Hello! This is Vidguard, the best partner for short video creators to protect their rights and interests.';

// 转为十六进制
const dataHex = ethers.hexlify(ethers.toUtf8Bytes(hashToStore));

async function main() {
  
  const tx = {
    to: wallet.address, 
    value: ethers.parseEther('0.00001'), //amount of crypto
    data: dataHex, // 用转换后的十六进制字符串
    gasLimit: 21000 + 10000, // add gas limit
  };


  const sentTx = await wallet.sendTransaction(tx);
  console.log('Transaction Sended，hash:', sentTx.hash);

  await sentTx.wait();
  console.log('Transaction On Chain！');
}

main().catch(console.error);