安装google cloud sdk https://cloud.google.com/sdk/docs/install

1. 安装 google-cloud-speech 和 google-cloud-aiplatform
在命令行（PowerShell 或 CMD）中运行：
pip install moviepy
pip install google-cloud-speech
pip install google-cloud-aiplatform
pip install pyperclip

2. 登陆vertex AI并替换selenium路径
https://console.cloud.google.com/vertex-ai/studio/multimodal?hl=zh-cn&project=scriptdetection-465907

#####不使用API不需要
#设置环境变量
#将下载的 JSON 密钥文件路径设置为环境变量：
#Windows 下可以在命令行运行（假设密钥文件放在 C:\Users\16695\Desktop\audiDetection\my-key.json

3. 为了避免谷歌自动化测试检测，需要a.为selenium单独开一个profile, b.手动登陆一次selenium会使用的profile
options.add_argument(r'--user-data-dir=C:\Users\16695\chrome_selenium_profile')
步骤一：用指定 profile 启动 Chrome 浏览器
关闭所有 Chrome 浏览器（确保没有进程占用 profile）。
用命令行启动 Chrome 并指定 user-data-dir：

步骤二：在新开的 Chrome 里登录 Google 账号
正常输入账号密码，完成登录（包括二次验证等）。
登录成功后关闭这个 Chrome 窗口

步骤三：用 Selenium 复用这个 profile

4. 替换上传视频存放位置：C:\Users\16695\Desktop\audiDetection\testVidCompressed.mp4
替换target_script位置C:\Users\16695\Desktop\audiDetection\script_pattern.txt


