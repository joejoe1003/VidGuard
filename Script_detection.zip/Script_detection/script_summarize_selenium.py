from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import pyperclip
import re
import difflib


options = webdriver.ChromeOptions()
options.add_argument(r'--user-data-dir=C:\Users\16695\chrome_selenium_profile')
options.add_experimental_option("excludeSwitches", ["enable-automation"])
options.add_experimental_option('useAutomationExtension', False)

driver = webdriver.Chrome(options=options)
driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
    "source": """
        Object.defineProperty(navigator, 'webdriver', {
          get: () => undefined
        })
    """
})

driver.get("https://console.cloud.google.com/vertex-ai/studio/multimodal?hl=zh-cn&project=scriptdetection-465907")


upload_input = WebDriverWait(driver, 60).until(
    EC.presence_of_element_located((By.XPATH, '//input[@type="file"]'))
)
upload_input.send_keys(r"C:\Users\16695\Desktop\audiDetection\testVidCompressed.mp4") 


prompt_input = WebDriverWait(driver, 60).until(
     EC.presence_of_element_located((By.XPATH, '//div[contains(@class, "ql-editor") and @contenteditable="true"]'))
)
prompt = "write down the dialogues in this video(what people said), don't include your thinking process into the output"
prompt_input.click()  
prompt_input.send_keys(prompt)




submit_btn = driver.find_element(By.XPATH, '//button[@id="_0rif_p6ntest-ai-llm-chat-prompt-send-button"]')
submit_btn.click()

copy_btn = WebDriverWait(driver, 60).until(
    EC.element_to_be_clickable((By.XPATH, '//button[contains(@class, "cfc-easy-copy-button")]'))
)
copy_btn.click()


time.sleep(1)  


copied_text = pyperclip.paste()


lines = copied_text.splitlines()
filtered_lines = []
for line in lines:

    if re.match(r'^\s*\*\*.*\*\*\s*$', line):
        continue
 
    if re.match(r'^\s*(I\'m|My goal|So far|In summary|Therefore|As a result|This means|Overall|To sum up|In conclusion)', line):
        continue
    filtered_lines.append(line)

filtered_text = '\n'.join(filtered_lines)


with open("Gemni.txt", "w", encoding="utf-8") as f:
    f.write(filtered_text)

print("复制输出的内容：")
print(filtered_text)

#similarity check 
with open(r"C:\Users\16695\Desktop\audiDetection\script_pattern.txt", "r", encoding="utf-8") as f:
    pattern_text = f.read()

similarity = difflib.SequenceMatcher(None, filtered_text, pattern_text).ratio()
print(f"与pattern的相似度: {similarity:.2%}")


driver.quit()